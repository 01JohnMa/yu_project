export default definePageConfig({
  // navigationBarTitleText: ''
})
