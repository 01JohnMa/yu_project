export default definePageConfig({
  // navigationBarTitleText: ''
})
